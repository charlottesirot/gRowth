library(testthat)
library(elementR)

test_check("elementR")
